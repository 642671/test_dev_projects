(function(){
  "use strict";
  const I=window.DiskCheckI18n;
  if(!I)return;
  const localized={
    "zh-CN":["退出等待","已从等待队列移除"],
    "zh-HK":["退出等待","已從等待佇列移除"],
    "en-US":["Remove from Queue","Removed from the waiting queue"],
    "ja-JP":["待機列から削除","待機列から削除しました"],
    "ko-KR":["대기열에서 제거","대기열에서 제거했습니다"],
    "de-DE":["Aus Warteschlange entfernen","Aus der Warteschlange entfernt"],
    "fr-FR":["Retirer de la file","Retiré de la file d’attente"],
    "es-ES":["Quitar de la cola","Se quitó de la cola de espera"],
    "hu-HU":["Eltávolítás a sorból","Eltávolítva a várakozási sorból"],
    "it-IT":["Rimuovi dalla coda","Rimosso dalla coda di attesa"],
    "pt-PT":["Remover da fila","Removido da fila de espera"],
    "ru-RU":["Удалить из очереди","Удалено из очереди ожидания"],
    "pl-PL":["Usuń z kolejki","Usunięto z kolejki oczekiwania"],
    "tr-TR":["Kuyruktan kaldır","Bekleme kuyruğundan kaldırıldı"],
    "vi-VN":["Xóa khỏi hàng đợi","Đã xóa khỏi hàng đợi chờ"],
    "id-ID":["Hapus dari Antrean","Dihapus dari antrean tunggu"],
    "th-TH":["นำออกจากคิว","นำออกจากคิวรอแล้ว"],
    "da-DK":["Fjern fra kø","Fjernet fra ventekøen"],
    "nb-NO":["Fjern fra kø","Fjernet fra ventekøen"],
    "cs-CZ":["Odebrat z fronty","Odebráno z čekací fronty"],
    "sv-SE":["Ta bort från kön","Borttagen från väntkön"],
    "nl-NL":["Uit wachtrij verwijderen","Uit de wachtrij verwijderd"],
    "ro-RO":["Elimină din coadă","Eliminat din coada de așteptare"],
    "el-GR":["Αφαίρεση από την ουρά","Αφαιρέθηκε από την ουρά αναμονής"]
  };
  const keys=["removeQueuedScan","queuedScanRemoved"];
  for(const [locale,values] of Object.entries(localized)){
    const messages=I.messages[locale];
    if(!messages)continue;
    keys.forEach((key,index)=>{messages[key]=values[index]});
  }
})();

// Chinese meaning -> English baseline -> all supported locales; one status per line.
(()=>{
  const colors={
    'zh-CN':'绿色：表示当前未发现风险。\n黄色：警告表示需要备份并复查。\n红色：危险表示数据损坏风险较高，应立即备份并更换磁盘。',
    'zh-HK':'綠色：表示目前未發現風險。\n黃色：警告表示需要備份並複查。\n紅色：危險表示資料損壞風險較高，應立即備份並更換磁碟。',
    'en-US':'Green: No risk is currently detected.\nYellow: Warning — back up and recheck.\nRed: Critical — high risk of data damage; back up immediately and replace the drive.',
    'de-DE':'Grün: Derzeit kein Risiko erkannt.\nGelb: Warnung — Daten sichern und erneut prüfen.\nRot: Kritisch — hohes Risiko von Datenschäden; sofort sichern und das Laufwerk ersetzen.',
    'fr-FR':'Vert : aucun risque détecté actuellement.\nJaune : avertissement — sauvegardez et vérifiez à nouveau.\nRouge : critique — risque élevé de corruption ; sauvegardez immédiatement et remplacez le disque.',
    'es-ES':'Verde: no se detecta riesgo actualmente.\nAmarillo: advertencia — haga una copia y vuelva a comprobar.\nRojo: crítico — alto riesgo de daños en los datos; haga una copia inmediata y sustituya la unidad.',
    'it-IT':'Verde: nessun rischio attualmente rilevato.\nGiallo: avviso — eseguire il backup e ricontrollare.\nRosso: critico — alto rischio di danni ai dati; eseguire subito il backup e sostituire l’unità.',
    'pt-PT':'Verde: nenhum risco detetado atualmente.\nAmarelo: aviso — faça uma cópia de segurança e volte a verificar.\nVermelho: crítico — risco elevado de danos nos dados; faça uma cópia imediata e substitua a unidade.',
    'hu-HU':'Zöld: jelenleg nem észlelhető kockázat.\nSárga: figyelmeztetés — készítsen biztonsági másolatot és ellenőrizze újra.\nPiros: kritikus — nagy az adatsérülés kockázata; azonnal készítsen mentést és cserélje ki a meghajtót.',
    'tr-TR':'Yeşil: şu anda risk tespit edilmedi.\nSarı: uyarı — yedekleyin ve yeniden kontrol edin.\nKırmızı: kritik — yüksek veri hasarı riski; hemen yedekleyin ve sürücüyü değiştirin.',
    'pl-PL':'Zielony: obecnie nie wykryto ryzyka.\nŻółty: ostrzeżenie — wykonaj kopię i sprawdź ponownie.\nCzerwony: stan krytyczny — wysokie ryzyko uszkodzenia danych; natychmiast wykonaj kopię i wymień dysk.',
    'ru-RU':'Зелёный: в настоящее время риск не обнаружен.\nЖёлтый: предупреждение — создайте резервную копию и проверьте повторно.\nКрасный: критическое состояние — высокий риск повреждения данных; немедленно создайте резервную копию и замените диск.',
    'ja-JP':'緑：現在リスクは検出されていません。\n黄：警告 — バックアップして再確認してください。\n赤：危険 — データ破損のリスクが高いため、直ちにバックアップしてドライブを交換してください。',
    'ko-KR':'녹색: 현재 위험이 감지되지 않았습니다.\n노란색: 경고 — 백업하고 다시 확인하십시오.\n빨간색: 위험 — 데이터 손상 위험이 높으므로 즉시 백업하고 드라이브를 교체하십시오.',
    'vi-VN':'Xanh lá: hiện chưa phát hiện rủi ro.\nVàng: cảnh báo — sao lưu và kiểm tra lại.\nĐỏ: nguy hiểm — nguy cơ hỏng dữ liệu cao; sao lưu ngay và thay ổ đĩa.',
    'id-ID':'Hijau: saat ini tidak terdeteksi risiko.\nKuning: peringatan — cadangkan dan periksa kembali.\nMerah: kritis — risiko kerusakan data tinggi; segera cadangkan dan ganti drive.',
    'th-TH':'สีเขียว: ขณะนี้ยังไม่พบความเสี่ยง\nสีเหลือง: คำเตือน — สำรองข้อมูลและตรวจสอบอีกครั้ง\nสีแดง: อันตราย — มีความเสี่ยงสูงที่ข้อมูลจะเสียหาย ให้สำรองข้อมูลทันทีและเปลี่ยนไดรฟ์',
    'da-DK':'Grøn: ingen risiko registreret i øjeblikket.\nGul: advarsel — sikkerhedskopiér og kontrollér igen.\nRød: kritisk — høj risiko for dataskade; sikkerhedskopiér straks og udskift drevet.',
    'nb-NO':'Grønn: ingen risiko oppdaget nå.\nGul: advarsel — sikkerhetskopier og kontroller på nytt.\nRød: kritisk — høy risiko for dataskade; sikkerhetskopier straks og bytt ut disken.',
    'cs-CZ':'Zelená: aktuálně nebylo zjištěno riziko.\nŽlutá: varování — zálohujte a znovu zkontrolujte.\nČervená: kritický stav — vysoké riziko poškození dat; ihned zálohujte a vyměňte disk.',
    'sv-SE':'Grön: ingen risk upptäckt för närvarande.\nGul: varning — säkerhetskopiera och kontrollera igen.\nRöd: kritiskt — hög risk för dataskada; säkerhetskopiera omedelbart och byt ut enheten.',
    'nl-NL':'Groen: momenteel geen risico gedetecteerd.\nGeel: waarschuwing — maak een back-up en controleer opnieuw.\nRood: kritiek — hoog risico op gegevensschade; maak onmiddellijk een back-up en vervang de schijf.',
    'ro-RO':'Verde: momentan nu este detectat niciun risc.\nGalben: avertisment — faceți o copie de siguranță și verificați din nou.\nRoșu: critic — risc ridicat de deteriorare a datelor; faceți imediat o copie și înlocuiți discul.',
    'el-GR':'Πράσινο: δεν εντοπίζεται κίνδυνος αυτήν τη στιγμή.\nΚίτρινο: προειδοποίηση — δημιουργήστε αντίγραφο ασφαλείας και ελέγξτε ξανά.\nΚόκκινο: κρίσιμο — υψηλός κίνδυνος βλάβης δεδομένων· δημιουργήστε αμέσως αντίγραφο ασφαλείας και αντικαταστήστε τον δίσκο.'
  };
  for(const [locale,text] of Object.entries(colors))window.DiskCheckI18n.messages[locale].helpOverviewText=text;
})();

(()=>{
  const requested={
    'zh-CN':'已提交停止请求','zh-HK':'已提交停止要求','en-US':'Stop Requested',
    'de-DE':'Stopp angefordert','fr-FR':'Arrêt demandé','es-ES':'Parada solicitada','it-IT':'Arresto richiesto','pt-PT':'Paragem solicitada',
    'hu-HU':'Leállítás kérve','tr-TR':'Durdurma istendi','pl-PL':'Zażądano zatrzymania','ru-RU':'Запрошена остановка',
    'ja-JP':'停止要求を送信済み','ko-KR':'중지 요청됨','vi-VN':'Đã yêu cầu dừng','id-ID':'Penghentian diminta','th-TH':'ส่งคำขอหยุดแล้ว',
    'da-DK':'Stop anmodet','nb-NO':'Stopp forespurt','cs-CZ':'Požadováno zastavení','sv-SE':'Stopp begärt','nl-NL':'Stop aangevraagd','ro-RO':'Oprire solicitată','el-GR':'Ζητήθηκε διακοπή'
  };
  for(const [locale,text] of Object.entries(requested))window.DiskCheckI18n.messages[locale].outcome_cancel_requested=text;
})();
